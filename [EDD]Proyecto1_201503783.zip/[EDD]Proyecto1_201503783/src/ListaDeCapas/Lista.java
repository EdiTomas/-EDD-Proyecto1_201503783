/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaDeCapas;

import Matrices.Capa;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class Lista {

    Nodo Primero;
    Nodo Ultimo;
    
    public Lista(){
        Primero = Ultimo = null;
    }
    
    
  public Boolean EstaVacio(){
 return Primero ==null && Ultimo ==null;
 }    
  

  public void InsertarAlfrente(int id, Capa cp)
{
   Nodo nuevo = new Nodo(id,cp);   
      if(EstaVacio())
      {
          nuevo.Siguiente=null;
          Primero = Ultimo = nuevo;
           System.out.println("Se inserto el primero con exito");
       }else{
            nuevo.Siguiente=Primero;
            Primero = nuevo;
            Ultimo.Siguiente=null;
            
     }
}
  

  
  
  
  
  public String RecorrerArbol(){
String Cuerpo = "";
String Despliegue = "";

   Nodo  Actual = Primero;
     while (Actual !=null){
         if(Primero == Actual){
                   Despliegue =  Primero.id + "[" +"label=" + "\""+"Capa"+ Primero.id+"|"+ Primero.id +""+"\"" +"]" +";"+"\n";  
                   Cuerpo =  Primero.id+" ";
         }else{
                  Despliegue += Actual.id + "[" +"label="+ "\""+Actual.id+"|"+ Actual.id +""+"\"" +"]" +";"+"\n" ;
                  //  Cuerpo +=  "\"->" + "\"" +" "+Actual.id;
                        Cuerpo +=  "->" +" "+Actual.id;
    
         }
         Actual = Actual.Siguiente;
     }
   return "\n"+ Despliegue+"\n"+ Cuerpo;
}

  
  
  
  
  
  
  public String Graficar(String id){
      String cuerpo="";     
      
            
            // Si el archivo no existe es creado
      cuerpo+= " subgraph cluster_ "+id+"{\n" +
            "" + " node[ shape=record, fontcolor=black, style=filled, color=coral1, width=0.5]  \n" +
"    edge[color=chartreuse1] \n" +
"      " +RecorrerArbol()+"\n"+"}";
   return cuerpo;
}
  
  


    
}
