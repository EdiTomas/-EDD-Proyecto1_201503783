/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABBCapas;

/**
 *
 * @author edi
 */
public class NodoABB {

private NodoABB izquierda;
private NodoABB derecha;
private int dato;
private Object capa; //  Por el momento es un objecto del tipo String
private String nombrecapa;
public NodoABB(){
  this.dato=0;
  this.nombrecapa ="";
  this.capa = null;
  this.derecha = null;
  this.izquierda = null;

}



public NodoABB(int dato, Object capa,String nombrecapa){
    this.setDato(dato);
    this.setCapa(capa);
    this.setDerecha(null);
    this.setIzquierda(null);
    this.setNombrecapa(nombrecapa);
}




    /**
     * @return the izquierda
     */
    public NodoABB getIzquierda() {
        return izquierda;
    }

    /**
     * @param izquierda the izquierda to set
     */
    public void setIzquierda(NodoABB izquierda) {
        this.izquierda = izquierda;
    }

    /**
     * @return the derecha
     */
    public NodoABB getDerecha() {
        return derecha;
    }

    /**
     * @param derecha the derecha to set
     */
    public void setDerecha(NodoABB derecha) {
        this.derecha = derecha;
    }

    /**
     * @return the dato
     */
    public int getDato() {
            return dato;
    }

    /**
     * @param dato the dato to set
     */
    public void setDato(int dato) {
        this.dato = dato;
    }

    /**
     * @return the capa
     */
    public Object getCapa() {
        return capa;
    }

    /**
     * @param capa the capa to set
     */
    public void setCapa(Object capa) {
        this.capa = capa;
    }

    /**
     * @return the nombrecapa
     */
    public String getNombrecapa() {
        return nombrecapa;
    }

    /**
     * @param nombrecapa the nombrecapa to set
     */
    public void setNombrecapa(String nombrecapa) {
        this.nombrecapa = nombrecapa;
    }


    
}
