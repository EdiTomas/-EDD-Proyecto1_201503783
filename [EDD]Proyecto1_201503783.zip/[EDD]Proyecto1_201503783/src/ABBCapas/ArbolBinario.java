/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABBCapas;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class ArbolBinario {

    public NodoABB raiz;

    public ArbolBinario() {
        raiz = null;

    }

    public void insertarNodo(int dato, Object capa,String NombreCapa) {

        raiz = insertar(raiz, dato, capa,NombreCapa);
    }

    public NodoABB insertar(NodoABB subraiz, int dato, Object capa,String nombreCapa) {
        if (subraiz == null) {
            subraiz = new NodoABB(dato, capa,nombreCapa);
        } else if (dato < subraiz.getDato()) {
            NodoABB izq = insertar(subraiz.getIzquierda(), dato, capa, nombreCapa);
            subraiz.setIzquierda(izq);
        } else {
            NodoABB der = insertar(subraiz.getDerecha(), dato, capa,nombreCapa);
            subraiz.setDerecha(der);
        }
        return subraiz;
    }

    public NodoABB buscar(NodoABB raiz, int dato) {

        if (raiz == null) {
            return null;
        } else if (dato == raiz.getDato()) {
            return raiz;
        } else if (dato < raiz.getDato()) {
            return buscar(raiz.getIzquierda(), dato);
        } else {
            return buscar(raiz.getDerecha(), dato);
        }

    }

    public boolean existe(NodoABB raiz, int dato){
        if (raiz == null) {
            return false;
        } else if (dato == raiz.getDato()) {
            return true;
        } else if (dato < raiz.getDato()) {
            return existe(raiz.getIzquierda(), dato);
        } else {
            return existe(raiz.getDerecha(), dato);
        }
    
    }    
    
    
    
    public void inOrden(NodoABB r) {

        if (r != null) {

            inOrden(r.getIzquierda());
            System.out.println(r.getDato());
            inOrden(r.getDerecha());
        }
    }
    
    
    public void PreOrden(NodoABB r){
        if(r !=null)
        {
              System.out.println(r.getDato());
              PreOrden(r.getIzquierda());
              PreOrden(r.getDerecha());
        }
    
    }
    
    public void PostOrden(NodoABB r){
        if(r !=null)
        {
              PostOrden(r.getIzquierda());
              PostOrden(r.getDerecha());
              System.out.println(r.getDato());
        }      
    }
    
    
    
    

    public void GraficarArbolBB(NodoABB raiz) {
        try {
            String ruta = "ArbolBB.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=TB; "
                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
            //   + "edge[color=chartreuse1] \n"

            );
            //  bw.write(this.RecorrerArbol(raiz) );
            bw.write(this.recorrer(raiz) + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "ArbolBB.png", "ArbolBB.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "ArbolBB.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    String cuerpo = "";
    Boolean NodoRaiz = true;

    public String recorrer(NodoABB raiz) {

        if (raiz != null) {
            cuerpo += "node" + raiz.getDato() + "[label = " + "\"<val>|" + raiz.getNombrecapa() + "|<ptr>\"" + "];\n";
            if (raiz.getIzquierda() != null) {
                cuerpo += "node" + raiz.getDato() + ":val->" + "node" + raiz.getIzquierda().getDato() + "\n";
                NodoRaiz = false;
            } else {
                // cuerpo +=  raiz.getDato()+ "->"+"null"+"\n" ;
                // NodoRaiz = false;   

            }
            recorrer(raiz.getIzquierda());
            if (raiz.getDerecha() != null) {
                cuerpo += "node" + raiz.getDato() + ":ptr->" + "node" + raiz.getDerecha().getDato() + "\n";
                NodoRaiz = false;
            } else {
                //   cuerpo +=  raiz.getDato()+ "->"+"null"+"\n" ;
                // NodoRaiz = false;   

            }

            recorrer(raiz.getDerecha());
         //   if (NodoRaiz) {
           //     cuerpo = "node" + raiz.getDato() + "\n";
           // }
        }

        return cuerpo;
    }

    
    
    
    public boolean deletenodo(int id)
    {
       NodoABB  aux= raiz;
       NodoABB  padre= raiz;
       boolean esHijoizq = true;
       while(aux.getDato() !=id){
           padre  = aux;
           if(id<aux.getDato()){
               esHijoizq =true;
               aux = aux.getIzquierda();
           }else{
               esHijoizq =false;
               aux = aux.getDerecha();
           }
           
           if(aux == null)
           {
              return false;
           }
       }// fin del while
            if(aux.getIzquierda() == null && aux.getDerecha() == null ){
                 if(aux == raiz){
                     raiz = null;
                 }else if(esHijoizq){
                    padre.setIzquierda(null);
                 }else{
                    padre.setDerecha(null);
                 }
                }else if(aux.getDerecha() == null){
                if(aux == raiz){
                     raiz = aux.getIzquierda();
                 }else if(esHijoizq){
                    padre.setIzquierda(aux.getIzquierda());
                 }else{
                    padre.setDerecha(aux.getIzquierda());
                 }
            }else if(aux.getIzquierda() == null){
                 
                if(aux == raiz){
                     raiz = aux.getDerecha();
                 }else if(esHijoizq){
                    padre.setIzquierda(aux.getDerecha());
                 }else{
                     ///
                    padre.setDerecha(aux.getDerecha());
                 }
            
            }else{
            
                NodoABB reemplazo= obtenerNodoRemplazo(aux);
               if(aux== raiz){
                   raiz = reemplazo;
               }else if(esHijoizq){
                  padre.setIzquierda(reemplazo);
               }else{
                  padre.setDerecha(reemplazo);
               }
               reemplazo.setIzquierda(aux.getIzquierda());
            } 
     return true;
    }
    
    public NodoABB  obtenerNodoRemplazo(NodoABB nodoReemp){
       NodoABB  reemplazarPadre = nodoReemp;
       NodoABB  reemplazo= nodoReemp;
       NodoABB  aux = nodoReemp.getDerecha();
          while(aux !=null){
          reemplazarPadre   = reemplazo;
          reemplazo = aux;
          aux = aux.getIzquierda();
          }
        if(reemplazo != nodoReemp.getDerecha()){
          reemplazarPadre.setDerecha(reemplazo.getDerecha());
          reemplazo.setDerecha(nodoReemp.getDerecha());
        }
        System.out.println("El nodo Reemplazo"+ reemplazo);
        return reemplazo;
        
    } 
    
    
    
    
    
















}
