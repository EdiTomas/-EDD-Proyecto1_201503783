/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

/**
 *
 * @author edi
 */
public class NodoMatriz {
    
    public int x;
   public int y;
   public String Color ;
   public NodoMatriz Arriba;
   public NodoMatriz Abajo;
   public NodoMatriz izquierda;
   public NodoMatriz derecha;

    public NodoMatriz(int x, int y, String Color ) {
        this.x = x;
        this.y = y;
        this.Color=Color;
        this.Arriba = null;
        this.Abajo = null;
        this.izquierda = null;
        this.derecha = null;
    }

    public NodoMatriz(int x, int y) {
    
       this.x=x;
       this.y=y;
       this.Color ="";    
    }
    
    
    
}
