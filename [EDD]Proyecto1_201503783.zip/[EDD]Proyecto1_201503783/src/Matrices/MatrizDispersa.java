/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class MatrizDispersa {

    public NodoMatriz Inicio;
    NodoMatriz cabezaCabecera;
    NodoMatriz cabezaLateral;

    NodoMatriz insertarCabecera;
    NodoMatriz insertarLateral;

    public MatrizDispersa() {
        Inicio = new NodoMatriz(0, 0, "Matriz");
        cabezaCabecera = Inicio.derecha;
        cabezaLateral = Inicio.Abajo;
    }

    public boolean existeCabecera(int x) {
        NodoMatriz aux;
        boolean existe = false;
        for (aux = cabezaCabecera; aux != null; aux = aux.derecha) {
            if (aux.x == x) {
                existe = true;
                break;
            }
        }
        return existe;
    }

    // la cabecera se va a mover atravez de las columnas
    public NodoMatriz Cabecera(int x) {
        NodoMatriz nuevo = new NodoMatriz(x, 0);
        if (cabezaCabecera == null) {
            cabezaCabecera = nuevo;
        } else if (x < cabezaCabecera.x) {
            nuevo.derecha = cabezaCabecera;
            nuevo.izquierda = Inicio;
            cabezaCabecera.izquierda = nuevo;
            cabezaCabecera = nuevo;
        } else {
            NodoMatriz Actual = cabezaCabecera;
            NodoMatriz Anterior;
            while (Actual.derecha != null) {
                Anterior = Actual;
                Actual = Actual.derecha;
            }
            if (Actual.x < x) {
                Actual.derecha = nuevo;
                nuevo.izquierda = Actual;
                Actual = nuevo;
            } else {
                Actual = Anterior = cabezaCabecera;
                while (Actual != null) {
                    if (Anterior.x < x && x < Actual.x) {
                        break;
                    } else {
                        Anterior = Actual;
                        Actual = Actual.derecha;
                    } // fin del else y el if
                }
                Anterior.derecha = nuevo;
                nuevo.izquierda = Anterior;
                nuevo.derecha = Actual;
                Actual.izquierda = nuevo;
            }
        }
        return nuevo;
    }

    public boolean existeLateral(int y) {
        NodoMatriz aux;
        boolean existe = false;
        for (aux = cabezaLateral; aux != null; aux = aux.Abajo) {
            if (aux.y == y) {
                existe = true;
                break;
            }
        }
        return existe;
    }

    public NodoMatriz Lateral(int y) {
        NodoMatriz nuevo = new NodoMatriz(0, y);
        if (cabezaLateral == null) {
            cabezaLateral = nuevo;
        } else if (y < cabezaLateral.y) {
            nuevo.Abajo = cabezaLateral;
            nuevo.Arriba = Inicio;
            cabezaLateral.Arriba = nuevo;
            cabezaLateral = nuevo;
        } else {
            NodoMatriz Actual = cabezaLateral;
            NodoMatriz Anterior;
            while (Actual.Abajo != null) {
                Anterior = Actual;
                Actual = Actual.Abajo;
            }
            if (Actual.y < y) {
                Actual.Abajo = nuevo;
                nuevo.Arriba = Actual;
                Actual = nuevo;
            } else {
                Actual = Anterior = cabezaLateral;
                while (Actual != null) {
                    if (Anterior.y < y && y < Actual.y) {
                        break;
                    } else {
                        Anterior = Actual;
                        Actual = Actual.Abajo;
                    } // fin del else y el if

                }
                Anterior.Abajo = nuevo;
                nuevo.Arriba = Anterior;
                nuevo.Abajo = Actual;
                Actual.Arriba = nuevo;
            }
        }
        return nuevo;
    }

    public void insertar(int x, int y, String color) {
        NodoMatriz nuevo = new NodoMatriz(x, y, color);

        if (existeLateral(y) == false && existeCabecera(x) == false) {
            insertarCabecera = Cabecera(x);
            insertarLateral = Lateral(y);

            nuevo.Arriba = insertarCabecera;
            insertarCabecera.Abajo = nuevo;
            insertarCabecera = nuevo;
            nuevo.izquierda = insertarLateral;
            insertarLateral.derecha = nuevo;
            insertarLateral = nuevo;
        } else if (existeLateral(y) == true && existeCabecera(x) == false) {
            insertarCabecera = Cabecera(x);

            nuevo.Arriba = insertarCabecera;
            insertarCabecera.Abajo = nuevo;
            insertarCabecera = nuevo;
            nuevo.izquierda = insertarLateral;
            insertarLateral.derecha = nuevo;
            insertarLateral = nuevo;

        } else if (existeLateral(y) == false && existeCabecera(x) == true) {
            insertarLateral = Lateral(y);
            nuevo.Arriba = insertarCabecera;
            insertarCabecera.Abajo = nuevo;
            insertarCabecera = nuevo;
            nuevo.izquierda = insertarLateral;
            insertarLateral.derecha = nuevo;
            insertarLateral = nuevo;
        } else if (existeLateral(y) == true && existeCabecera(x) == true) {

            nuevo.Arriba = insertarCabecera;
            insertarCabecera.Abajo = nuevo;
            insertarCabecera = nuevo;
            nuevo.izquierda = insertarLateral;
            insertarLateral.derecha = nuevo;
            insertarLateral = nuevo;
        }
    }

    public void Imprimir() {
        //  NodoMatriz ActualColumna = cabezaCabecera;
        NodoMatriz ActualColumna = Inicio.derecha;
        NodoMatriz ActualFila = Inicio.Abajo;

        while (ActualFila != null) {

            while (ActualColumna != null) {
                System.out.println("Dato " + ActualColumna.Color + " Fila " + ActualColumna.x + " Columna " + ActualColumna.y);
                ActualColumna = ActualColumna.derecha;
            }

            ActualFila = ActualFila.Abajo;
        }
}

    public void GraficarMatriz() {
        try {
            String ruta = "Matriz.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G { \n"
                    + "node [shape=plaintext]\n"
                    + "a [label=<<TABLE BORDER=\"1\" CELLBORDER=\"0\" CELLSPACING=\"0\">"
            );
            bw.write(this.RecorrerMatriz() + "\n" + "</TABLE>>];" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "Matriz.png", "Matriz.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "Matriz.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int TamanoColumna() {
        int size = 0;
        NodoMatriz aux;
        for (aux = cabezaCabecera; aux != null; aux = aux.derecha) {
            size++;
        }
        return size;
    }

    public int TamanoFila() {
        int size = 0;
        NodoMatriz aux;
        for (aux = cabezaLateral; aux != null; aux = aux.Abajo) {
            size++;
        }
        return size;
    }

    //*********************************************************************************
    public NodoMatriz buscarCabecera(int x) {
        NodoMatriz aux = null;
        for (aux = cabezaCabecera; aux != null; aux = aux.derecha) {
            if (aux.x == x) {
                return aux;
            }
        }
        return aux;
    }

    public NodoMatriz buscarLateral(int y) {
        NodoMatriz aux;
        for (aux = cabezaLateral; aux != null; aux = aux.Abajo) {
            if (aux.y == y) {
                return aux;
            }
        }
        return aux;
    }

    public NodoMatriz buscarNodo(int x, int y) {
        NodoMatriz aux;
        NodoMatriz aux1;
        for (aux = cabezaLateral; aux != null; aux = aux.Abajo) {
            for (aux1 = aux.derecha; aux1 != null; aux1 = aux1.derecha) {
                if (aux1.x == x && aux1.y == y) {
                    return aux1;
                }
            }
        }
        return null;
    }

    
    public void LimpiarMatriz(){
     Inicio = null;
    }
    
    
    public String RecorrerMatriz() {
        String cuerpo = "";
        int i, j;
       for (i = 0; i <= TamanoFila(); i++) {
                      cuerpo += "<TR>";
                  for (j = 0; j <= TamanoColumna(); j++) {
                        if(buscarNodo(j,i) ==null)
                        {
                        cuerpo += "<TD BGCOLOR=\"#FFFFFF\">" + "</TD>";
                         }else{
                             cuerpo += "<TD BGCOLOR=" + "\"" + buscarNodo(j,i).Color + "\"" + ">" + "</TD>";
                         }   
                  }
                    cuerpo += "</TR>" + "\n";
         }
        return cuerpo;
    }
     
    public String Recorrer(){
    
            String cuerpo ="";
      
        
         NodoMatriz ActualColumna = cabezaCabecera;
          cuerpo += "{";
              cuerpo += "rank=same" + ";\n";
           while (ActualColumna != null) {
                NodoMatriz ActualFila = ActualColumna.Abajo;
                while(ActualFila!=null){
                cuerpo += "node" + ActualFila.x + "_" + ActualFila.y + "[label = " + ActualFila.Color + "];\n";
                  ActualFila = ActualFila.Abajo;
                }
                  ActualColumna = ActualColumna.derecha;
            }
           cuerpo += "} \n";
        
          
        
    //**************************************Cabecera***************************************    
        
        cuerpo += "{" + "\n";
       cuerpo += "rank=same" + ";\n";
        int contadorcolumna = 1;
        ActualColumna = cabezaCabecera;
        while (ActualColumna != null) {
            cuerpo += "x" + ActualColumna.x + "[label = C_" + (contadorcolumna++) + "," + "rankdir=UD" + "];\n";
            ActualColumna = ActualColumna.derecha;
        }
cuerpo += "}" + ";\n";
     


 cuerpo +=  " {" + "\n";
        cuerpo += "rank=min" + ";\n";
         NodoMatriz Actual = Inicio;
       do {
            cuerpo += "m" + "[label = " + "Matriz" + "];\n";
         } while (Actual != Inicio); 
       
  NodoMatriz  ActualFila = cabezaLateral;
        
       int contador = 1;
        while (ActualFila != null) {
            cuerpo += "y" + ActualFila.y + "[label = F_" + (contador++) + "," + "rankdir=LR" + "];\n";
            ActualFila = ActualFila.Abajo;
        }
         cuerpo += "}" + ";\n";
    return cuerpo;
 }
    
    
    
    
    public String RecorrerLateral()
    {
       String cuerpo ="";
        NodoMatriz  Columna;
        NodoMatriz Fila;
        
        for (Fila = cabezaLateral; Fila != null; Fila = Fila.Abajo) {
                      
            for (Columna = Fila.derecha; Columna != null; Columna = Columna.derecha) {
                 if(Columna.izquierda == buscarLateral(Fila.y) && Columna.derecha == null){
                      cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"y"+Columna.izquierda.y+"\n" ;
                      cuerpo += "y"+Columna.y +"->"+"node"+Columna.x+"_"+Columna.y+"\n" ;
                   }else if(Columna.izquierda== buscarLateral(Fila.y) && Columna.derecha != null){
                      cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"node"+Columna.derecha.x+"_"+Columna.derecha.y+"\n"  ;           
                   }else if(Columna.izquierda != buscarLateral(Fila.y) && Columna.derecha == null){
                    cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"node"+Columna.izquierda.x+"_"+Columna.izquierda.y+"\n";           
                    }else{
                    cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"node"+Columna.derecha.x+"_"+Columna.derecha.y  ;           
                    cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"node"+Columna.izquierda.x+"_"+Columna.izquierda.y+"\n";           
                  }
            }
        }
 return cuerpo;
    }
    
    public String RecorrerCabecera(){
    String  cuerpo ="";
        NodoMatriz  Columna;
        NodoMatriz Fila;
        
    for (Columna = cabezaCabecera; Columna != null; Columna = Columna.derecha) {
                      
            for (Fila = Columna.Abajo; Fila != null; Fila = Fila.Abajo) {
        
                if(Fila.Arriba == buscarCabecera(Columna.x) && Fila.Abajo == null){
                      cuerpo += "node"+Fila.x+"_"+Fila.y +"->"+"x"+Fila.Arriba.y+"\n" ;
                      cuerpo += "x"+Fila.y +"->"+"node"+Fila.x+"_"+Fila.y+"\n" ;
                  }else if(Fila.Arriba== buscarCabecera(Columna.x) && Fila.Abajo != null){
                    cuerpo += "node"+Fila.x+"_"+Fila.y +"->"+"node"+Fila.Abajo.x+"_"+Fila.Abajo.y+"\n"  ;           
                  //  cuerpo += "node"+Columna.x+"_"+Columna.y +"->"+"y"+Columna.izquierda.y;
                  }else if(Fila.Arriba != buscarCabecera(Columna.x) && Fila.Arriba == null){
                    cuerpo += "node"+Fila.x+"_"+Fila.y +"->"+"node"+Fila.Arriba.x+"_"+Fila.Arriba.y+"\n";           
                  
                  }else{
                    cuerpo += "node"+Fila.x+"_"+Fila.y +"->"+"node"+Fila.Abajo.x+"_"+Fila.Abajo.y  ;           
                    cuerpo += "node"+Fila.x+"_"+Fila.y +"->"+"node"+Fila.Arriba.x+"_"+Fila.Arriba.y+"\n";           
                  }
            }
        }
    return cuerpo;
    }
    
    
    public void RGraficar(){
    
    try {
            String ruta = "Matrices.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=LR; "
                    + "" + " node[ shape=record, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
            );
            
               bw.write(Recorrer()+"\n" );
               bw.write(this.RecorrerLateral()+"\n" );
               bw.write(this.RecorrerCabecera()+"\n" );
               
            
          //  bw.write(RecorrerArbol() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "Matrices.png", "Matrices.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "Matrices.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    public String recorrercuadro() {
        String cuerpo = "";
        NodoMatriz ActualFila = cabezaLateral;
        while (ActualFila != null) {
            cuerpo += "<TR>";
            NodoMatriz ActualColumna = ActualFila.derecha;
            while (ActualColumna != null) {
                cuerpo += "<TD BGCOLOR=" + "\"" + ActualColumna.Color + "\"" + ">" + "</TD>";
                ActualColumna = ActualColumna.derecha;
            }
            cuerpo += "</TR>" + "\n";
            ActualFila = ActualFila.Abajo;
        }

        return cuerpo;
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
