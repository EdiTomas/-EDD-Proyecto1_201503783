/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AVLUsuarios;

/**
 *
 * @author edi
 */
public class NodoAvl {

  public int id;
  public NodoAvl derecho;
  public NodoAvl izquierdo;
  public String nombre;
  public int fe;
  final Comparable valor;

  
  
  public NodoAvl(int id,String nombre){
this.id = id;
this.nombre = nombre;

this.izquierdo=null; 
this.derecho = null;
fe = 0;
valor =null;
}




private static int correlativo=1;
public NodoAvl(Comparable valor, String nombre){

this.valor =valor;
this.izquierdo=null; 
this.derecho = null;
this.fe = fe;
this.id = correlativo++;
this.nombre = nombre;
}

public NodoAvl(int id, int fe,NodoAvl derecho, NodoAvl izquierdo){

this.id = id;
this.izquierdo= izquierdo;
this.derecho = derecho;
this.fe = fe;
valor =null;

}












    
}
