/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AVLUsuarios;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class ArbolAVL {

    public NodoAvl raiz;

    public ArbolAVL() {
        raiz = null;
    }

    public NodoAvl buscar(int id, NodoAvl r) {
        if (r == null) {
            return null;
        } else if (r.id == id) {
            return r;
        } else if (r.id < id) {
            return buscar(id, r.derecho);
        } else {

            return buscar(id, r.izquierdo);
        }
    }

public void Modificar(int id,NodoAvl r ,String nombre){

        if (r == null) {
            System.out.println("No existe");
        } else if ( (int)(r.valor) == id) {
                    r.nombre=nombre ;
        } else if ((int)(r.valor) < id) {
            this.Modificar(id, r.derecho, nombre);
        } else {
            this.Modificar(id, r.izquierdo, nombre);
        }

}    
    
    
    
    
    
    
    
    public int obtenerFe(NodoAvl avl) {
        if (avl == null) {
            return -1;
        } else {
            return avl.fe;
        }
    }

    public NodoAvl rotacionIzquierda(NodoAvl c) {
        NodoAvl aux = c.izquierdo;
        c.izquierdo = aux.derecho;
        aux.derecho = c;
        c.fe = Math.max(obtenerFe(c.izquierdo), obtenerFe(c.derecho) )+1;
        aux.fe = Math.max(obtenerFe(aux.izquierdo), obtenerFe(aux.derecho) )+1;
       // aux.fe = Math.max(obtenerFe(aux.izquierdo), c.fe)+1;
     return aux;
    }

    public NodoAvl rotacionDerecha(NodoAvl c) {
        NodoAvl aux = c.derecho;
        c.derecho = aux.izquierdo;
        aux.izquierdo = c;
        c.fe = Math.max(obtenerFe(c.izquierdo), obtenerFe(c.derecho) )+1;
        aux.fe = Math.max(obtenerFe(aux.izquierdo), obtenerFe(aux.derecho) )+1;
     //  aux.fe = Math.max(obtenerFe(aux.izquierdo), c.fe)+1;
       
       return aux;
    }
      
    public NodoAvl rotacionDobleIzquierda(NodoAvl c) {
        NodoAvl temporal;
        c.izquierdo = rotacionDerecha(c.izquierdo);
        temporal = rotacionIzquierda(c);
        return temporal;
    }

    public NodoAvl rotacionDobleDerecha(NodoAvl c) {
        NodoAvl temporal;
        c.derecho = rotacionIzquierda(c.derecho);
        temporal = rotacionDerecha(c);
        return temporal;
    }

    public NodoAvl insertarAVL(NodoAvl nuevo, NodoAvl subArbol) {
        NodoAvl nuevoPadre = subArbol;
        if (nuevo.id < subArbol.id) // primero if
        {
            if (subArbol.izquierdo == null) {   // segundo if
                subArbol.izquierdo = nuevo;
            } else {
                subArbol.izquierdo = insertarAVL(nuevo, subArbol.izquierdo);
                if ((obtenerFe(subArbol.izquierdo) - obtenerFe(subArbol.derecho)) == 2) {   // tercer if
                    if (nuevo.id < subArbol.izquierdo.id) { // cuarto if
                        nuevoPadre = rotacionIzquierda(subArbol);
                    } else {
                        nuevoPadre = rotacionDobleIzquierda(subArbol);
                    }  // termina el else y el if del cuarto if
                }// cierre del tercer if
            }  // cierre del segundo if
        } else if (nuevo.id > subArbol.id) {    // else del primer if
            if (subArbol.derecho == null) {
                subArbol.derecho = nuevo;
            } else {
                subArbol.derecho = insertarAVL(nuevo, subArbol.derecho);
                if ((obtenerFe(subArbol.derecho) - obtenerFe(subArbol.izquierdo)) == 2) {

                    if (nuevo.id < subArbol.derecho.id) {
                        nuevoPadre = rotacionDerecha(subArbol);
                    } else {
                        nuevoPadre = rotacionDobleDerecha(subArbol);
                    }
                }
            }

        } else{ // termina el elseif del primer if
            System.out.println("Nodo duplicado");
        } 
          ///********************Alturas****************************************
           if( (subArbol.izquierdo ==null) && (subArbol.derecho !=null))
           {
              subArbol.fe= subArbol.derecho.fe+1;
           }else if((subArbol.derecho ==null) && (subArbol.izquierdo !=null)){
              subArbol.fe = subArbol.izquierdo.fe+1; 
           }else{
              subArbol.fe = Math.max(obtenerFe(subArbol.izquierdo), obtenerFe(subArbol.derecho) + 1);
           }
     return nuevoPadre;       
    }

     //*****************************Inserscion perfecto de Avl************************************************
    public void insercion(Comparable valor,String usuario){
    raiz = insertaravl(valor,usuario,raiz);
    }
    
    
     private NodoAvl insertaravl(Comparable valor,String usuario, NodoAvl raiz){
        
        if(raiz == null){
            raiz = new NodoAvl(valor,usuario);
        }else if(valor.compareTo(raiz.valor) < 0 ){
            raiz.izquierdo = insertaravl(valor,usuario, raiz.izquierdo);            
              
                if(obtenerFe(raiz.derecho)-obtenerFe(raiz.izquierdo) == -2)
                

                   if(valor.compareTo(raiz.izquierdo.valor) < 0)
                              raiz = rotacionIzquierda(raiz);
                          else
                              raiz = rotacionDobleIzquierda(raiz);
        }
        else if(valor.compareTo(raiz.valor)>0)
        {
            raiz.derecho=insertaravl(valor,usuario, raiz.derecho);            
            if(obtenerFe(raiz.derecho)-obtenerFe(raiz.izquierdo) == 2)
                if(valor.compareTo(raiz.derecho.valor) > 0)
                            raiz = rotacionDerecha(raiz);
                else
                     raiz = rotacionDobleDerecha(raiz);
        }

        else  
        System.err.println("No se permiten los valores duplicados: \"" 
                +  String.valueOf(valor)+"\".");        
        
        raiz.fe = Math.max(obtenerFe(raiz.izquierdo), obtenerFe(raiz.derecho))+1;
        return raiz;
}
        
   public boolean EstaVacio(){
      
      return raiz == null;
   }  

   
   //************************Equilibrar Avl***************************
  public void AjustarAvl(int dato,NodoAvl raiz ){
    
        if(!EstaVacio())
        {
           
             if(dato >(int)(raiz.valor))
             {
                AjustarAvl(dato,raiz.derecho);
             }else if(dato < (int)(raiz.valor))
             {
                AjustarAvl(dato,raiz.izquierdo);
             }
    
             
               switch(obtenerFe(raiz.derecho)-obtenerFe(raiz.izquierdo)){
                   case 2:
                       if(obtenerFe(raiz.izquierdo.izquierdo)> obtenerFe(raiz.izquierdo.derecho))
                       {
                       raiz = rotacionDerecha(raiz);
                       }
                       else{
                       raiz = rotacionDobleIzquierda(raiz);
                        }
                       break;
               case -2:
                      if(obtenerFe(raiz.derecho.derecho)> obtenerFe(raiz.derecho.izquierdo))
                       {
                       raiz = rotacionIzquierda(raiz);
                       }
                       else{
                              raiz = rotacionDobleDerecha(raiz);
                        }
                  break;
               default:
                raiz.fe = Math.max(obtenerFe(raiz.izquierdo), obtenerFe(raiz.derecho))+1;
           }
        }else{
            System.out.println("No existe arbol avl");
            return ;
        
        }
    
    }

  public void eliminar(int dato){
       this.Borrar(dato, raiz);
  }
  
public void Borrar(int dato,NodoAvl raiz)
{
   
    NodoAvl p, aux, dest;
    
    int tipoelemento;
    
    p = raiz;
    tipoelemento = dato;
    
    while((int)(p.valor) != dato){
        tipoelemento = (int)(p.valor);     
          if((int)(p.valor)>dato)
            p=p.izquierdo;
          else 
              p=p.derecho;
    }
  
        if(p.izquierdo!=null && p.derecho !=null ){
           aux =p.derecho;
            tipoelemento = (int)(p.valor);     
            while(aux.izquierdo !=null){
            tipoelemento = (int)(aux.valor);     
               aux = aux.izquierdo;
            }
            p.valor.compareTo(aux.valor);
          p=aux;
        }
        if(p.izquierdo==null && p.derecho==null)
        {
           p = null;
        }else if(p.izquierdo==null){
          dest =p;  
          p = p.derecho;
          dest =null;
        }else{
            dest =p;  
            p= p.izquierdo;
        dest = null;
        }
         AjustarAvl( dato, raiz );
}



    
    
    
    
    
    
    
    
    
    
    
    
    public void insertar(int id , String usuario)
    {
        NodoAvl nuevo = new NodoAvl(id,usuario);
        if(raiz==null){
           raiz = nuevo;
        }else{
           raiz= insertarAVL(nuevo,raiz); 
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public void mostraAvl(){
    
    this.GraficarArbolBB(raiz);
    }
    
    
    
      public void GraficarArbolBB(NodoAvl raiz){
        try {
            String ruta = "ArbolAvl.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=TB; "
                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
                         //   + "edge[color=chartreuse1] \n"
            
            );
       //  bw.write(this.RecorrerArbol(raiz) );
            bw.write(this.recorrer(raiz) + "\n" + "}");
                 cuerpo = "";
            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "ArbolAvl.png", "ArbolAvl.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "ArbolAvl.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    
    }
    
    
   String cuerpo="";
   Boolean NodoRaiz = true;
    public String recorrer(NodoAvl raiz){
      if(raiz !=null){
        cuerpo += "node" + raiz.valor+ "[label = " + "\"<val>|"   +raiz.valor +":  "+    raiz.nombre + "|<ptr>\"" + "];\n";
        if (raiz.izquierdo != null)
          {
            cuerpo +=  "node"+raiz.valor+ ":val->"+"node"+raiz.izquierdo.valor+"\n" ;
             NodoRaiz = false;
       }else{
         // cuerpo +=  raiz.getDato()+ "->"+"null"+"\n" ;
         // NodoRaiz = false;   
         
        }
       recorrer(raiz.izquierdo);
       if (raiz.derecho != null)
       {
       cuerpo +=  "node"+raiz.valor+":ptr->"+ "node"+raiz.derecho.valor+"\n" ;
       NodoRaiz = false;
       }
       else{
       //   cuerpo +=  raiz.getDato()+ "->"+"null"+"\n" ;
         // NodoRaiz = false;   
          
        }
       
      recorrer(raiz.derecho);
      if(NodoRaiz){
           cuerpo = "node"+ raiz.valor+"\n";
         }
      }
         
      
      
      return cuerpo;
  }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
