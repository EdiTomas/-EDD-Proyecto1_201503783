/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.proyecto1_201503783;

import ABBCapas.ArbolBinario;
//import static ABBCapas.ArbolBinario.raiz;
import ABBCapas.NodoABB;
import ListaCircularImagenes.ListaCircularDoble;
import MatrizDispersa.Matriz;
import AVLUsuarios.ArbolAVL;
import static FaseCompilador.GeneradorCompilador.generarcompiladores;
import static FaseCompilador2.Compilador.compiladores;
import javax.swing.JFrame;
import org.jvnet.substance.SubstanceLookAndFeel;

/**
 *
 * @author edi
 */
public class EDDProyecto1_201503783 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         JFrame.setDefaultLookAndFeelDecorated(true);
         SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.RavenSkin");
          generarcompiladores();
       //   compiladores();
         
         
        Ventana vn = new Ventana();
        vn.show();

        
        
        
        
        
    }
    
}
