/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class ListaH {
    int x;
    NodoM primero, ultimo;

    public ListaH() {
        primero = null;
        ultimo = null;
        x = 0;
    } 
    
    public void insertar(NodoM n){
        //insertar ordenado
        ultimo.setDer(n);
        n.setIzq(ultimo);
        ultimo = n;
    }
    
}
