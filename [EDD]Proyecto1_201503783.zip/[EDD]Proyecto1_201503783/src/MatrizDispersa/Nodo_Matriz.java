
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class Nodo_Matriz {
    
    int numeroFila;
    int numeroColumna;
    String colorNodo;
    Nodo_Matriz siguienteFila;
    Nodo_Matriz siguienteColumna;
    Nodo_Matriz anteriorFila;
    Nodo_Matriz anteriorColumna;
    
    //Crear las cabeceras y laterales
    public Nodo_Matriz(int numeroFila, int numeroColumna){
        this.numeroFila = numeroFila;
        this.numeroColumna = numeroColumna;
        this.colorNodo = "";
    }
    
    //Crear los enlaces en los nodos
    public Nodo_Matriz(int numeroFila, int numeroColumna, String colorNodo){
        this.numeroFila = numeroFila;
        this.numeroColumna = numeroColumna;
        this.colorNodo = colorNodo;
    }
    
    
}
