/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class ListaV {
    int x;
    NodoM primero, ultimo;

    public ListaV() {
        primero = null;
        ultimo = null;
        x = 0;
    } 
    
    public void insertar(NodoM n){
        //insertar ordenado
        if(primero  == null){
            primero = ultimo = n;
        }else{
            ultimo.setAbajo(n);
            n.setArriba(ultimo);
            ultimo = n;
        }
    }
}
