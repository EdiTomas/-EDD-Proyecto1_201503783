/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class NodoLateral {
    private ListaH lista;
    private int y;
    private NodoLateral arriba;
    private NodoLateral abajo;

    public NodoLateral(int y) {
        this.lista = new ListaH();
        this.y = y;
        this.arriba = null;
        this.abajo = null;
    }

    /**
     * @return the lista
     */
    public ListaH getLista() {
        return lista;
    }

    /**
     * @param lista the lista to set
     */
    public void setLista(ListaH lista) {
        this.lista = lista;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the arriba
     */
    public NodoLateral getArriba() {
        return arriba;
    }

    /**
     * @param arriba the arriba to set
     */
    public void setArriba(NodoLateral arriba) {
        this.arriba = arriba;
    }

    /**
     * @return the abajo
     */
    public NodoLateral getAbajo() {
        return abajo;
    }

    /**
     * @param abajo the abajo to set
     */
    public void setAbajo(NodoLateral abajo) {
        this.abajo = abajo;
    }
    
}
