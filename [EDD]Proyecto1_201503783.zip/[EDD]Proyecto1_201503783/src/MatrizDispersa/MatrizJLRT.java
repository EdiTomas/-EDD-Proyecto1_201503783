/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class MatrizJLRT {
    ListaM cabeceras;
    ListaLateral laterales;
    
    public MatrizJLRT(int id) {
        this.cabeceras = new ListaM();
        this.laterales = new ListaLateral();
    }
    
    public void insertar(int x, int y, String color){
        NodoM nuevo = new NodoM(x, y, color);
        if(!cabeceras.existe(x)){
            cabeceras.insertar(new NodoCabecera(x));
        }
        if(!laterales.existe(y)){
            laterales.insertar(new NodoLateral(y));
        }
        
        cabeceras.obtenerNodo(x).getListav().insertar(nuevo);
        laterales.obtenerNodo(y).getLista().insertar(nuevo);
    }
    
    public void recorrer(){
        NodoLateral aux = laterales.primero;
        while(aux!=null){
            //recorrer
            NodoM nodo = aux.getLista().primero;
            while(nodo!=null){
                //recorrer
                nodo = nodo.getDer();
            }
            aux = aux.getAbajo();
        }
        
    }

    
}
