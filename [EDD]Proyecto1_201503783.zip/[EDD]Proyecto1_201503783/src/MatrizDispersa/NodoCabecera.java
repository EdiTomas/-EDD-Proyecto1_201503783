/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class NodoCabecera {
    private ListaV listav;
    private int x;
    private NodoCabecera sig;
    private NodoCabecera ant;

    public NodoCabecera(int x) {
        this.listav = new ListaV();
        this.x = x;
        this.sig = null;
        this.ant = null;
    }

    /**
     * @return the listav
     */
    public ListaV getListav() {
        return listav;
    }

    /**
     * @param listav the listav to set
     */
    public void setListav(ListaV listav) {
        this.listav = listav;
    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the sig
     */
    public NodoCabecera getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoCabecera sig) {
        this.sig = sig;
    }

    /**
     * @return the ant
     */
    public NodoCabecera getAnt() {
        return ant;
    }

    /**
     * @param ant the ant to set
     */
    public void setAnt(NodoCabecera ant) {
        this.ant = ant;
    }
    
    
}
