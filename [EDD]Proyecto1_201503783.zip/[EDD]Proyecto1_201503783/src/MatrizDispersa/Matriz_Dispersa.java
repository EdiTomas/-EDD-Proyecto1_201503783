/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class Matriz_Dispersa {
    
    Nodo_Matriz inicioColumna;
    Nodo_Matriz finColumna;
    Nodo_Matriz inicioFila;
    Nodo_Matriz finFila;
    Nodo_Matriz inicioMatrizDispersa;
    
    
    public Matriz_Dispersa(){
        
        inicioMatrizDispersa = new Nodo_Matriz(0,0);
        inicioColumna = finColumna = inicioMatrizDispersa;
        inicioFila = finFila = inicioMatrizDispersa;
        
    }
    
    public void insertar(int fila, int columna, String color){
        
        //Verifico si existe la columna
        if(!existeCabecera(columna)){
            
            crearCabecera(columna);
            
            //verifico si existe la fila
            if(!existeLateral(fila)){
                
                crearLateral(fila);
                
                ingresarNodo(fila,columna,color);
            }
            
            //
            else{
                
                ingresarNodo(fila,columna,color);
            }
        }
        
        //Existe la columna
        else{
            
            //Verifico si existe la fila
            if(!existeLateral(fila)){
                
                crearLateral(fila);
                
                ingresarNodo(fila,columna,color);
            }
            
            //
            else{
                
                ingresarNodo(fila,columna,color);
            }
        }
        
    }
    
    public void ingresarNodo(int fila, int columna, String color){
        
    }
    
    public void crearLateral(int fila){
        
    }
    
    public void crearCabecera(int columna){
        
        Nodo_Matriz nuevaColumna = new Nodo_Matriz(0,columna);
        
        if(columna >= finColumna.numeroColumna){
            inicioColumna.siguienteColumna = nuevaColumna;
            nuevaColumna.anteriorColumna = inicioColumna;
            finColumna = nuevaColumna;
        }
        else{
            
            Nodo_Matriz auxiliar = inicioColumna;
            while( auxiliar.siguienteColumna != null ){
                
                if( auxiliar.siguienteColumna.numeroColumna < columna ){
                    auxiliar.siguienteColumna.anteriorColumna = nuevaColumna;
                    nuevaColumna.siguienteColumna = auxiliar.siguienteColumna;
                    nuevaColumna.anteriorColumna = auxiliar;
                    auxiliar.siguienteColumna = nuevaColumna;
                    break;
                }else if( auxiliar.siguienteColumna.numeroColumna == columna ){
                    break;
                }
                
                auxiliar = auxiliar.siguienteColumna;
            }
        }
        
    }
    
    
    public boolean existeCabecera(int columna){
        
        Nodo_Matriz auxiliar = inicioColumna;
        
        while( auxiliar != null){
            
            if(auxiliar.numeroColumna == columna)
                return true;
            
            auxiliar = auxiliar.siguienteColumna;
        }        
        
        return false;
    }
    
    public boolean existeLateral(int fila){
        
        Nodo_Matriz auxiliar = inicioFila;
        
        while( auxiliar != null){
            
            if(auxiliar.numeroFila == fila)
                return true;
            
            auxiliar = auxiliar.siguienteFila;
        }
        
        return false;
    }
    
    
    
}
