/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class Matriz {

    public NodoMatriz inicio;

    public Matriz() {
        inicio = new NodoMatriz(0, 0, "Matriz");
       // inicio.setSigFila(null);
       // inicio.setSigColumna(null);
        
    }

    public NodoMatriz insertarFila(int fila) {
        NodoMatriz cabeza = inicio.getSigFila();
        NodoMatriz nuevo = new NodoMatriz(fila, 0, "");
        if (cabeza == null) {
            inicio.setSigFila(nuevo);
            nuevo.setAntFila(inicio);
        } else {
            if (cabeza.getFila() > fila) {
                nuevo.setSigFila(cabeza);
                cabeza.setAntFila(nuevo);
                inicio.setSigFila(nuevo);
                nuevo.setAntFila(inicio);
            } else {
                NodoMatriz aux = cabeza;
                while (aux.getSigFila() != null) {
                    if (aux.getSigFila().getFila() > fila) {
                        nuevo.setSigFila(aux.getSigFila());
                        aux.getSigFila().setAntFila(nuevo);
                        aux.setSigFila(nuevo);
                        nuevo.setAntFila(aux);
                        return nuevo;
                    }
                    aux = aux.getSigFila();
                }
                aux.setSigFila(nuevo);
                nuevo.setAntFila(aux);
            }

        }
        return nuevo;

    }

    public NodoMatriz obtenerFila(int fila) {
        NodoMatriz aux;

        for (aux = inicio.getSigFila(); aux != null; aux = aux.getSigFila()) {
            if (aux.getFila() == fila) {
                return aux;
            }
        }

        return insertarFila(fila);
    }

    public NodoMatriz insertarColumna(int columna) {
        NodoMatriz cabeza = inicio.getSigColumna();
        NodoMatriz nuevo = new NodoMatriz(0, columna, "");
        if (cabeza == null) {
            inicio.setSigColumna(nuevo);
            nuevo.setAntColumna(inicio);
        } else {
            if (cabeza.getColumna() > columna) {
                nuevo.setSigColumna(cabeza);
                cabeza.setAntColumna(nuevo);
                inicio.setSigColumna(nuevo);
                nuevo.setAntColumna(inicio);
            } else {
                NodoMatriz aux = cabeza;
                while (aux.getSigColumna() != null) {
                    if (aux.getSigColumna().getColumna() > columna) {
                        nuevo.setSigColumna(aux.getSigColumna());
                        aux.getSigColumna().setAntColumna(nuevo);
                        aux.setSigColumna(nuevo);
                        nuevo.setAntColumna(aux);
                        return nuevo;
                    }
                    aux = aux.getSigColumna();
                }
                aux.setSigColumna(nuevo);
                nuevo.setAntColumna(aux);
            }

        }
        return nuevo;

    }

    public NodoMatriz obtenerColumna(int columna) {
        NodoMatriz aux;
        for (aux = inicio.getSigColumna(); aux != null; aux = aux.getSigColumna()) {
            if (aux.getColumna() == columna) {
                return aux;
            }
        }
        return insertarColumna(columna);
    }

    public void insertarMatriz(int fila, int columna, String color) {
        NodoMatriz nuevo = new NodoMatriz(fila, columna, color);
        NodoMatriz nuevaColumna = obtenerFila(fila);
        NodoMatriz nuevaFila = obtenerColumna(columna);
        NodoMatriz cabeceraFila = nuevaColumna.getSigColumna();
        NodoMatriz cabeceraColumna = nuevaFila.getSigFila();
        if (cabeceraFila == null) {
            nuevaColumna.setSigColumna(nuevo);
            nuevo.setAntColumna(nuevaColumna);
        } else {
            if (cabeceraFila.getColumna() > nuevo.getColumna()) {
                nuevo.setSigColumna(cabeceraFila);
                cabeceraFila.setAntColumna(nuevo);
                nuevaColumna.setSigColumna(nuevo);
                nuevo.setAntColumna(nuevaColumna);
            } else {
                NodoMatriz aux = cabeceraFila;
                while (aux.getSigColumna() != null) {
                    if (aux.getSigColumna().getColumna() < nuevo.getColumna()) {
                        nuevo.setSigColumna(aux.getSigColumna());
                        aux.getSigColumna().setAntColumna(nuevo);
                        aux.setSigColumna(nuevo);
                        nuevo.setAntColumna(aux);
                    }
                    aux = aux.getSigColumna();
                }
                aux.setSigColumna(nuevo);
                nuevo.setAntColumna(aux);
            }

        }

        if (cabeceraColumna == null) {
            nuevaFila.setSigFila(nuevo);
            nuevo.setAntFila(nuevaFila);
        } else {
            if (cabeceraColumna.getFila() > nuevo.getFila()) {
                nuevo.setSigFila(cabeceraFila);
                cabeceraFila.setAntFila(nuevo);
                nuevaFila.setSigFila(nuevo);
                nuevo.setAntFila(nuevaFila);
            } else {
                NodoMatriz aux = cabeceraColumna;
                while (aux.getSigFila() != null) {
                    if (aux.getSigFila().getFila() < nuevo.getFila()) {
                        nuevo.setSigFila(aux.getSigFila());
                        aux.getSigFila().setAntFila(nuevo);
                        aux.setSigFila(nuevo);
                        nuevo.setAntFila(aux);
                    }
                    aux = aux.getSigFila();
                }
                aux.setSigFila(nuevo);
                nuevo.setAntFila(aux);
            }

        }

    }

    public void imprimirRaiz() {
        NodoMatriz Actual = inicio;
        do {
            System.out.println("Dato " + Actual.getColor() + " Fila " + Actual.getFila() + " Columna " + Actual.getColumna());

        } while (Actual != inicio);

    }

    public int TamanoColumna(){
       int size =0;
         NodoMatriz aux;
         for (aux = inicio.getSigColumna(); aux != null; aux = aux.getSigColumna()) {
            size++;
         }
    return size;
    }
    
    public int TamanoFila(){
       int size =0;
         NodoMatriz aux;
         for (aux = inicio.getSigFila(); aux != null; aux = aux.getSigFila()){
            size++;
         }
    return size;
    }
    
    
    
    public String Capa(){
    String cuerpo ="";
       NodoMatriz ActualColumna = inicio.getSigColumna().getSigFila();
        while (ActualColumna != null) {
            NodoMatriz ActualFila = ActualColumna.getSigFila();
            while (ActualFila != null) {
            //    System.out.println("Dato " + ActualFila.getColor() + " Fila " + ActualFila.getFila() + " Columna " + ActualFila.getColumna());
                  cuerpo += ActualFila.getColor()+" ";
                  ActualFila = ActualFila.getSigFila();
            }
             cuerpo += ActualColumna.getColor()+" ";
            ActualColumna = ActualColumna.getSigColumna();
        }
         
    return cuerpo;
    } 
   
    
    
    
    
    public void imprimir() {
        NodoMatriz ActualColumna = inicio.getSigColumna();
        while (ActualColumna != null) {
            NodoMatriz ActualFila = ActualColumna.getSigFila();
            while (ActualFila != null) {
                System.out.println("Dato " + ActualFila.getColor() + " Fila " + ActualFila.getFila() + " Columna " + ActualFila.getColumna());
                ActualFila = ActualFila.getSigFila();
            }
            ActualColumna = ActualColumna.getSigColumna();
        }

    }

    
    
    
    
    
    
    public String Recorrido() {
        String Cuerpo = "";

        NodoMatriz ActualColumna = inicio.getSigColumna();
       
        
        
        Cuerpo += "{";
              Cuerpo += "rank=same" + ";\n";

        while (ActualColumna != null) {
            NodoMatriz ActualFila = ActualColumna.getSigFila();
            while (ActualFila != null) {
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "[label = " + ActualFila.getColor() + "];\n";
                ActualFila = ActualFila.getSigFila();
            }
            ActualColumna = ActualColumna.getSigColumna();
        }
        Cuerpo += "} \n";
        
        
        
        
        
        
       
           ActualColumna = inicio.getSigColumna();
          while (ActualColumna != null) {
            NodoMatriz ActualFila = ActualColumna.getSigFila();
            while (ActualFila != null) {
            if (ActualFila.getAntFila() == null && ActualFila.getSigFila() == null) {

            } else if (ActualFila.getAntFila() != null && ActualFila.getSigFila() != null) {
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getSigFila().getColumna() + "_" + ActualFila.getSigFila().getFila() + ";\n";
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "x" + ActualFila.getSigFila().getFila() + "_" + ActualFila.getSigFila().getColumna() + ";\n";
                Cuerpo += "y" + ActualFila.getColumna() + "_" + ActualFila.getFila() + "->" + "node" + ActualFila.getSigFila().getColumna() + "_" + ActualFila.getSigFila().getFila() + ";\n";
                Cuerpo += "x" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "node" + ActualFila.getSigFila().getFila() + "_" + ActualFila.getSigFila().getColumna() + ";\n";
                
              //  Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getSigColumna().getColumna() + "_" + ActualFila.getSigColumna().getFila() + ";\n";
              //  Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "x" + ActualFila.getSigColumna().getFila() + "_" + ActualFila.getSigColumna().getColumna() + ";\n";
                
                
                
            } 
            else if (ActualFila.getAntFila() != null && ActualFila.getSigFila() == null) {
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getAntFila().getColumna() + "_" + ActualFila.getAntFila().getFila() + ";\n";
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "x" + ActualFila.getAntFila().getFila() + "_" + ActualFila.getAntFila().getColumna() + ";\n";
                  
                
            } else {

                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getAntFila().getColumna() + "_" + ActualFila.getAntFila().getFila() + ";\n";
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "x" + ActualFila.getAntFila().getFila() + "_" + ActualFila.getAntFila().getColumna() + ";\n";
               
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getSigFila().getColumna() + "_" + ActualFila.getSigFila().getFila() + ";\n";
                Cuerpo += "node" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "x" + ActualFila.getSigFila().getFila() + "_" + ActualFila.getSigFila().getColumna() + ";\n";
                   Cuerpo+= "*****************************Reultado*******************************";    
        
            }
            ActualFila = ActualFila.getSigFila();
        
            }
            ActualColumna = ActualColumna.getSigColumna();
        }
        
        NodoMatriz ActualFila = inicio.getSigFila();
       
        /*
          while(ActualFila!=null){
                 ActualColumna = ActualFila.getSigFila();
           
          while (ActualColumna != null) {

            if (ActualColumna.getAntColumna() == null && ActualColumna.getSigColumna() == null) {

            } else if (ActualColumna.getAntColumna() != null && ActualColumna.getSigColumna() != null) {
          //      Cuerpo += "xy" + 0 + "_" + 0 + "->" + "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + ";\n";
            //    Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getSigColumna().getFila() + "_" + ActualColumna.getSigColumna().getColumna() + ";\n";

            } else if (ActualColumna.getAntColumna() != null && ActualColumna.getSigColumna() == null) {

                   Cuerpo += "x" + ActualFila.getColumna() + "_" + ActualFila.getFila() + "->" + "node" + ActualFila.getAntFila().getColumna() + "_" + ActualFila.getAntFila().getFila() + ";\n";
                   Cuerpo += "y" + ActualFila.getColumna() + "_" + ActualFila.getFila() + "->" + "node" + ActualFila.getAntFila().getFila() + "_" + ActualFila.getAntFila().getColumna() + ";\n";
              
              //  Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getAntColumna().getFila() + "_" + ActualColumna.getAntColumna().getColumna() + ";\n";

            } else {
//                Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getAntColumna().getFila() + "_" + ActualColumna.getAntColumna().getColumna() + ";\n";
  //              Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getSigColumna().getFila() + "_" + ActualColumna.getSigColumna().getColumna() + ";\n";

            }
            ActualColumna = ActualColumna.getSigColumna();
        }
          ActualFila = ActualFila.getSigFila();
         }
         */ 
          
          
          
          
          
          
        
        
        
        
        
       
      //******************Columna*******************************************
        
Cuerpo += "{" + "\n";
Cuerpo += "rank=same" + ";\n";
        int contadorcolumna = 1;
        ActualColumna = inicio.getSigColumna();
        while (ActualColumna != null) {
            Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "[label = F_" + (contadorcolumna++) + "," + "rankdir=UD" + "];\n";
            ActualColumna = ActualColumna.getSigColumna();
        }
Cuerpo += "}" + ";\n";
        
        
        
        

        ActualColumna = inicio.getSigColumna();

        while (ActualColumna != null) {

            if (ActualColumna.getAntColumna() == null && ActualColumna.getSigColumna() == null) {

                // Cuerpo += "xy" + 0+"_"+0 + "->" + "x" + ActualColumna.getSigColumna().getFila()+"_"+ActualColumna.getSigColumna().getColumna() + ";\n";
            } else if (ActualColumna.getAntColumna() == inicio && ActualColumna.getSigColumna() != null) {
                Cuerpo += "xy" + 0 + "_" + 0 + "->" + "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + ";\n";
                Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getSigColumna().getFila() + "_" + ActualColumna.getSigColumna().getColumna() + ";\n";

            } else if (ActualColumna.getAntColumna() != null && ActualColumna.getSigColumna() == null) {

                // "xy" + 0+"_"+0+
                Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getAntColumna().getFila() + "_" + ActualColumna.getAntColumna().getColumna() + ";\n";

            } else {
                Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getAntColumna().getFila() + "_" + ActualColumna.getAntColumna().getColumna() + ";\n";
                Cuerpo += "x" + ActualColumna.getFila() + "_" + ActualColumna.getColumna() + "->" + "x" + ActualColumna.getSigColumna().getFila() + "_" + ActualColumna.getSigColumna().getColumna() + ";\n";

            }
            ActualColumna = ActualColumna.getSigColumna();
        }

        ///*************************fila************************************
        
        Cuerpo += " "
                + " {" + "\n";
        Cuerpo += "rank=min" + ";\n";

        NodoMatriz Actual = inicio;
       do {
            Cuerpo += "xy" + 0 + "_" + 0 + "[label = " + "Matriz" + "];\n";
         } while (Actual != inicio); 
        
        
        
        int contador = 1;
        while (ActualFila != null) {
            Cuerpo += "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "[label = C_" + (contador++) + "," + "rankdir=LR" + "];\n";
            ActualFila = ActualFila.getSigFila();
        }

        Cuerpo += "}" + ";\n";

        ActualFila = inicio.getSigFila();

        while (ActualFila != null) {

            if (ActualFila.getAntFila() == null && ActualFila.getSigFila() == null) {

            } else if (ActualFila.getAntFila() == inicio && ActualFila.getSigFila() != null) {
                Cuerpo += "xy" + 0 + "_" + 0 + "->" + "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + ";\n";
                Cuerpo += "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getSigFila().getFila() + "_" + ActualFila.getSigFila().getColumna() + ";\n";
            } else if (ActualFila.getAntFila() != null && ActualFila.getSigFila() == null) {
                Cuerpo += "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getAntFila().getFila() + "_" + ActualFila.getAntFila().getColumna() + ";\n";

            } else {

                Cuerpo += "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getAntFila().getFila() + "_" + ActualFila.getAntFila().getColumna() + ";\n";
                Cuerpo += "y" + ActualFila.getFila() + "_" + ActualFila.getColumna() + "->" + "y" + ActualFila.getSigFila().getFila() + "_" + ActualFila.getSigFila().getColumna() + ";\n";
            }
            ActualFila = ActualFila.getSigFila();
        }
return Cuerpo;
    }

    public String recorrerMatriz() {
        String cadena = "";
                
                
                
        return cadena;
    }

}
