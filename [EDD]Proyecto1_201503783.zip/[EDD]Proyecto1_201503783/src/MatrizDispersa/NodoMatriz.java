/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class NodoMatriz 
{
 private int fila;
 private int columna;
 private String Color;
 private NodoMatriz SigFila;
 private NodoMatriz SigColumna;
 private NodoMatriz AntFila;
 private NodoMatriz AntColumna;
         
 
 public NodoMatriz(){
 
 }
 
 
 
  public NodoMatriz(int fila, int columna , String Color ){
   this.setFila(fila);
   this.setColumna(columna);
   this.setColor(Color);
   this.AntColumna = null;
   this.SigFila= null;
   this.SigColumna=null;
   this.AntFila=null;
   this.AntColumna= null;
  }  

  
  public NodoMatriz(int fila, int columna ){
   this.setFila(fila);
   this.setColumna(columna);
   this.AntColumna = null;
   this.SigFila= null;
   this.SigColumna=null;
   this.AntFila=null;
   this.AntColumna= null;
  }
  
  
  
  
    /**
  z  * @return the fila
     */
    public int getFila() {
        return fila;
    }

    /**
     * @param fila the fila to set
     */
    public void setFila(int fila) {
        this.fila = fila;
    }

    /**
     * @return the columna
     */
    public int getColumna() {
        return columna;
    }

    /**
     * @param columna the columna to set
     */
    public void setColumna(int columna) {
        this.columna = columna;
    }

    /**
     * @return the Color
     */
    public String getColor() {
        return Color;
    }

    /**
     * @param Color the Color to set
     */
    public void setColor(String Color) {
        this.Color = Color;
    }

    /**
     * @return the SigFila
     */
    public NodoMatriz getSigFila() {
        return SigFila;
    }

    /**
     * @param SigFila the SigFila to set
     */
    public void setSigFila(NodoMatriz SigFila) {
        this.SigFila = SigFila;
    }

    /**
     * @return the SigColumna
     */
    public NodoMatriz getSigColumna() {
        return SigColumna;
    }

    /**
     * @param SigColumna the SigColumna to set
     */
    public void setSigColumna(NodoMatriz SigColumna) {
        this.SigColumna = SigColumna;
    }

    /**
     * @return the AntFila
     */
    public NodoMatriz getAntFila() {
        return AntFila;
    }

    /**
     * @param AntFila the AntFila to set
     */
    public void setAntFila(NodoMatriz AntFila) {
        this.AntFila = AntFila;
    }

    /**
     * @return the AntColumna
     */
    public NodoMatriz getAntColumna() {
        return AntColumna;
    }

    /**
     * @param AntColumna the AntColumna to set
     */
    public void setAntColumna(NodoMatriz AntColumna) {
        this.AntColumna = AntColumna;
    }
    
    
    
}
