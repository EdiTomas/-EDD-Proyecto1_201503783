/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatrizDispersa;

/**
 *
 * @author edi
 */
public class ListaLateral {
    NodoLateral primero, ultimo;

    public ListaLateral() {
        primero = null;
        ultimo = null;
    }
    
    public void insertar(NodoLateral l){
        
        //insertar ordenado
    }
    
    public boolean existe(int y){
        return true;
    }
    
    public NodoLateral obtenerNodo(int y){
        NodoLateral aux = primero;
        while(aux != null){
            
        }
        return new NodoLateral(1);
    }
    
}
