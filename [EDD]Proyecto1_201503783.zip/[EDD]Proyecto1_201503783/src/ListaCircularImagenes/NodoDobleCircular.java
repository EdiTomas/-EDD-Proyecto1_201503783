/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaCircularImagenes;

import ListaDeCapas.Lista;

/**
 *
 * @author edi
 */
public class NodoDobleCircular {
    private int id ;
    private Lista listadeCapas;
    private NodoDobleCircular Siguiente;
    private NodoDobleCircular Anterior; 
    
    
    public NodoDobleCircular(int id ,Lista listadeCapas){
         this.setId(id);
         this.setListadeCapas(listadeCapas);
         this.setSiguiente(null);
         this.setAnterior(null);
    
    }
    
    
    
    
    
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the capas
     */
    
    /**
     * @return the Siguiente
     */
    public NodoDobleCircular getSiguiente() {
        return Siguiente;
    }

    /**
     * @param Siguiente the Siguiente to set
     */
    public void setSiguiente(NodoDobleCircular Siguiente) {
        this.Siguiente = Siguiente;
    }

    /**
     * @return the Anterior
     */
    public NodoDobleCircular getAnterior() {
        return Anterior;
    }

    /**
     * @param Anterior the Anterior to set
     */
    public void setAnterior(NodoDobleCircular Anterior) {
        this.Anterior = Anterior;
    }

    /**
     * @return the listadeCapas
     */
    public Lista getListadeCapas() {
        return listadeCapas;
    }

    /**
     * @param listadeCapas the listadeCapas to set
     */
    public void setListadeCapas(Lista listadeCapas) {
        this.listadeCapas = listadeCapas;
    }
   
   
   
}
