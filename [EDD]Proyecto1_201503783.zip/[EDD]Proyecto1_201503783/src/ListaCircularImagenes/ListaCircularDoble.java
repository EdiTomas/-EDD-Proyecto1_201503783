/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaCircularImagenes;

import ListaDeCapas.Lista;
import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class ListaCircularDoble {
    NodoDobleCircular Primero;
    NodoDobleCircular Ultimo;
    
    public ListaCircularDoble(){
     Primero=null;
     Ultimo=null;
    }
    
    
    
public Boolean EstaVacia() {

        return Primero == null && Ultimo == null;
    }


public void insertarListaDobleCircular(int id, Lista capas) {
       NodoDobleCircular Nuevo = new NodoDobleCircular(id, capas);
        if (EstaVacia()) {
            Primero = Ultimo = Nuevo;
            Primero.setSiguiente(Ultimo);
            Ultimo.setSiguiente(Primero);
            Primero.setAnterior(Ultimo);
            Ultimo.setAnterior(Primero);
        } else if (id < Primero.getId()) {

            Nuevo.setSiguiente(Primero);
            Primero.setAnterior(Nuevo);
            Nuevo.setAnterior(Ultimo);
            Primero = Nuevo;
            Ultimo.setSiguiente(Primero);

        } else if (Ultimo.getId() < id) {
            Ultimo.setSiguiente(Nuevo);
            Primero.setAnterior(Nuevo);
            Nuevo.setAnterior(Ultimo);
            Nuevo.setSiguiente(Primero);
            Ultimo = Nuevo;

        } else {
            NodoDobleCircular actual = Primero;
            NodoDobleCircular Anterior = Primero;
            do {
                if (Anterior.getId() < id && id < actual.getId()) {
                    break;
                } else {
                    Anterior = actual;
                    actual = actual.getSiguiente();
                }  // fin del else if 
            } while (actual != Primero);

            Anterior.setSiguiente(Nuevo);
            Nuevo.setAnterior(Anterior);
            Nuevo.setSiguiente(actual);
            actual.setAnterior(Nuevo);
        }

    }

    public String RecorrerListaCircular() {

        String Cuerpo = "";

        if (!EstaVacia()) {
            NodoDobleCircular Actual = Primero;
            NodoDobleCircular Anterior = null;
            do {
                Cuerpo += "node" + Actual.getId() + "[label = " + "\"{<val> ant |" + Actual.getId() + " \n " +"Imagen" +"|<ptr> sig}\"" + "];\n";
                
                if(Actual.getListadeCapas() !=null){
                
                Cuerpo += Actual.getListadeCapas().Graficar("ImagenUsuario"+Actual.getId());
                Cuerpo += Actual.getId() + "->" + Primero.getId()+"";
                }
                Actual = Actual.getSiguiente();
            } while (Actual != Primero);

            Actual = Primero;

            do {
                if (Actual.getAnterior() == Primero && Actual.getSiguiente() == Primero) {
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getAnterior().getId() + ";\n";
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getSiguiente().getId() + ";\n";
                  }  else {

                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getAnterior().getId() + ";\n";
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getSiguiente().getId() + ";\n";
                }
                Actual = Actual.getSiguiente();
            } while (Actual != Primero);
             } else {
            System.out.println("La lista Esta Vacia");
        }
        return Cuerpo;
    }
      
    public Boolean Existe(int id) {
        Boolean existe = false;
        NodoDobleCircular actual = Primero;
         do {
            if (id == actual.getId()) {
                existe = true;
                break;
            }
            actual = actual.getSiguiente();
        } while (actual != Primero);
           return existe;
    }
    
    
    public NodoDobleCircular buscar(int id) {
        
        NodoDobleCircular actual = Primero;
         do {
            if (id == actual.getId()) {
                return actual;
            }
            actual = actual.getSiguiente();
        } while (actual != Primero);
           return null;
    }
    
    
    
    /*
    public void Modificar(int id,Object capas) {
        if (!EstaVacia()) {
            NodoDobleCircular nuevo = new NodoDobleCircular(id,capas) ;
            
            NodoDobleCircular Actual = Primero;
            NodoDobleCircular Anterior = null;
            while (Actual != null) {
                if (id == Actual.getId()) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
              if (Actual != null) {

                if (Primero == Actual && Ultimo == Actual) {
                    System.out.println("id : " + Actual.getId() + " Se ha Modificado con exito!");
                    Primero = Ultimo = null;
                    Primero = Ultimo = nuevo;
                    Primero.setSiguiente(Ultimo);
                    Ultimo.setSiguiente(Primero);
                    Primero.setAnterior(Ultimo);
                    Ultimo.setAnterior(Primero);
                } else if (Actual == Primero) {
                    System.out.println("id : " + Actual.getId() + "Se ha Modificado con exito!");
                    // Primero = Primero.getSiguiente();
                    Primero = null;
                   
                    nuevo.setSiguiente(Actual.getSiguiente());
                    Actual.setAnterior(nuevo);
                    nuevo.setAnterior(Ultimo);
                    Ultimo.setSiguiente(nuevo);
                    Primero = nuevo;
                } else if (Actual == Ultimo) {
                    System.out.println("id : " + Actual.getId() + "Se ha Modificado con exito!");
                    
                    Anterior.setSiguiente(nuevo);
                    nuevo.setAnterior(Anterior);
                    nuevo.setSiguiente(Primero);
                    Primero.setAnterior(nuevo);
                    Ultimo = nuevo;
                } else {
                    System.out.println("id : " + Actual.getId() + "Se ha Modificado con exito!");
                     
                     Anterior.setSiguiente(nuevo);
                     nuevo.setAnterior(Anterior);
                     nuevo.setSiguiente(Actual.getSiguiente());
                     Actual.getSiguiente().setAnterior(nuevo);
                     Actual=nuevo;
                }
             
            }
        } else {
            System.out.println("La lista esta Vacia");
        }
    }
    
    
    
    */
    
    
    
    
    

    public void Eliminiar(int id) {
        if (!EstaVacia()) {
            NodoDobleCircular Actual = Primero;
            NodoDobleCircular Anterior = null;
            while (Actual != null) {
                if (id == Actual.getId()) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
              if (Actual != null) {

                if (Primero == Actual && Ultimo == Actual) {
                    System.out.println("id : " + Actual.getId() + " Se ha Eliminado con exito!");
                    Primero = Ultimo = null;
                  //  Primero.setSiguiente(null);
                } else if (Actual == Primero) {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    // Primero = Primero.getSiguiente();
                    Primero = null;
                    Actual = Actual.getSiguiente();
                    Primero = Actual;
                    Primero.setAnterior(Ultimo);
                    Ultimo.setSiguiente(Primero);
                } else if (Actual == Ultimo) {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    Anterior.setSiguiente(Primero);
                    Primero.setAnterior(Anterior);
                 } else {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    Anterior.setSiguiente(Actual.getSiguiente());
                    Actual.getSiguiente().setAnterior(Actual.getAnterior());
//   Actual.setSiguiente(null);
                }
                Actual = null;
            }
        } else {
            System.out.println("La lista esta Vacia");
        }
    }
    
    
    
    
    
public void GraficarListaDoblementeCircular() {
        try {
            String ruta = "listadoblementecircular.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=LR; "
                    + "" + " node[ shape=record, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
            );
            bw.write(this.RecorrerListaCircular() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "listadoblementecircular.png", "listadoblementecircular.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "listadoblementecircular.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }













}
